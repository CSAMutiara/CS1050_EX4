package aup.cs;

import java.util.Arrays;

/**
 * The class is defined as final since utility classes should not be extensible.
 * Responsibility: Executes rounds of playing the Roulette game: gets bids from Player, spins
 * wheel and checks Outcomes
 * Interacts with Table, Wheel and Outcome
 */

public final class Game {
    
    public Table table;
    public Wheel wheel;
    public Player player;
    
    /**
     * Game constructor.
     */
    public Game() {
        Table table = new Table();
        Wheel wheel = new Wheel();
        Player player = new Player();
    }
    
    /**
     * betIsWinning checks if simulated outcome matches player's bet.
     * @param bet the Bet to compare with the simulated...
     * @param winning Bin
     * @return a boolean for if they match or not
     */
    public static boolean betIsWinning(Bet bet, Bin winning) {
        Outcome[] outcomes = winning.getOutcomes();
        Outcome outcome = bet.getOutcome();
        for (int i = 0; i < outcomes.length; i++) {
            if (outcomes[i].equalsOutcome(outcome)) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * cycle accepts Player p's values to run game simulation, and modifies p's.
     * values based on the simulation's outcome
     * @param p the Player that is inquiring the statistics of their bet
     */
    public void cycle(Player p) {
        player.placeBetsOnTable(table);
        Bin winningBin = wheel.next();
        Outcome[] outcomes = winningBin.getOutcomes();
        player.observeWinningOutcomes(outcomes);
        Bet[] bets = table.createBets();
        for (int i = 0; i < bets.length; i++) {
            if (betIsWinning(bets[i],  winningBin)) {
                player.win(bets[i]);
            } else {
                player.lose(bets[i]);
            }
        }
        table.clean();
    }    
    
    /**
     * Main method.
     */
    public static void main(String[] args) {
        
        
    }
    
}