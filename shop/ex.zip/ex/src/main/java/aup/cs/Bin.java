package aup.cs;

import java.util.ArrayList;

/**
 * The class is defined as final since utility classes should not be extensible.
 * Responsibility: Represents a bin in the Roulette and is capable of telling the winning Outcomes
 * Interacts: with Outcomes
 */ 

public final class Bin {
    
    private ArrayList<Outcome> outcomes;
    
    /**
     * Bin constructor.
     */
    public Bin() {
        this.outcomes = new ArrayList<Outcome>();
    }
    
    /**
     * Gets outcome array.
     * @return an outcome array
     */
    public Outcome[] getOutcomes() {
        return outcomes.toArray(new Outcome[0]);
    }
    
    /**
     * addOutcome add o to the bin.
     * @param o the Outcome that will be added to outcomes the ArrayList
     */
    public void addOutcome(Outcome o) {
        outcomes.add(o);
    }
    
}