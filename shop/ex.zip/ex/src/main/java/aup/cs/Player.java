package aup.cs;

import java.util.Arrays;

/**
 * The class is defined as final since utility classes should not be extensible.
 * Responsibility: Places Bets on Outcomes, update stakes
 * Interacts with Table to place bets
 */

public final class Player {
    
    private double stake;
    private double betMoney;
    private int maxCycle;
    private int numCycle;
    private boolean isPlaying;
    private boolean isBetting;
    private Table table;
    private Bet playerBet;
    
    /**
     * Player constructor.
     */
    public Player() {
        
    }
    
    /**
     * Player constructor.
     * @param t the Table
     */
    public Player(Table t) {
        this.table = t;
    }
    
    /**
     * plays allows the player to play in a game cycle.
     * @return a boolean stating if the player is participating in a game or not
     */
    public boolean plays() {
        while (isPlaying) {
            if (numCycle <= maxCycle) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * placeBets instantiates a Player's isBetting boolean.
     * @param t the Table 
     */
    public void placeBetsOnTable(Table t) {
        Bet[] b = t.createBets();
        t.placeBet(b);
    }
    
    /**
     * observeWinningOutcomes.
     * @param c the simulated Outcome[] the player wants to observe
     */
    public void observeWinningOutcomes(Outcome[] c) {
        
    }
    
    /**
     * win adjusts a Player's stake accordingly after player wins.
     * @param b Bet determines stake
     */
    public void win(Bet b) {
        Outcome o = b.getOutcome();
        stake += betMoney * o.getOdds();
    }
    
    /**
     * lose adjusts a Player's stake accordingly after player loses.
     * @param b Bet determines stake
     */
    public void lose(Bet b) {
        Outcome o = b.getOutcome();
        stake -= betMoney;
    }
    
}