package aup.cs;

import java.util.Arrays;

/**
 * The class is defined as final since utility classes should not be extensible.
 * Responsibility: Represents a certain Roulette outcome and contains its odd
 */

public final class Outcome {
    
    private String name;
    private int odds;
    
    /**
     * Outcome constructor.
     */
    public Outcome(String n, int o) {
        this.name = n;
        this.odds = o;
    }
    
    /**
     * Outcome constructor.
     */
    public Outcome(String n) {
        this.name = n;
    }
    
    /**
     * getOdds gets odds.
     * @return odds
     */
    public int getOdds() {
        return odds;
    }
    
    /**
     * equalsOutcome verifies if the simulated outcomes match the Outcome o.
     * @param o the Outcome bet by Player p.
     * @return a boolean stating if they match or not
     */
    public boolean equalsOutcome(Outcome o) {
        return this.name.equals(o.name);
    }
    
}