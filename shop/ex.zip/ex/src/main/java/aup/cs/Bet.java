package aup.cs;

import java.util.Arrays;

/**
 * The class is defined as final since utility classes should not be extensible.
 * Responsibility: Contain an amount of money and an Outcome, can compute won amount
 * Interacts with Outcomes
 */

public final class Bet {
    
    private Outcome outcome;
    
    /**
     * Bet constructor.
     */
    public Bet(String s) {
        this.outcome = new Outcome(s);
    }
    
    /**
     * Gets outcome.
     * @return outcome
     */
    public Outcome getOutcome() {
        return this.outcome;
    }
    
}