package aup.cs;

import java.util.Arrays;

/**
 * The class is defined as final since utility classes should not be extensible.
 */

public final class Table {
    
    private Bet[] bets;
    
    /**
     * Table constructor.
     */
    public Table() {
        
    }
    
    /**
     * createBets returns bets the Bet[] from all participating players of game.
     * @return bets the Bet array 
     */
    public Bet[] createBets() {
        return bets;
    }
    
    /**
     * placeBets sets the Bets array bets.
     * @param b a Bets[]
    */
    public void placeBet(Bet[] b) {
        this.bets = b;
    }
    
    /**
     * clean clears bets at the end of each cycle of each game.
    */
    public void clean() {
        bets = null;
    }
    
}