package aup.cs;

import java.util.Arrays;
import java.util.Random; 

public final class Statistics {
    
    /**
     * Statistics constructor.
     */
    public Statistics() {
        
    }
    
}