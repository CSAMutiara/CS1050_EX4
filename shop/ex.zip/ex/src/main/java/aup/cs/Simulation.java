package aup.cs;

import java.util.Arrays;

/**
 * The class is defined as final since utility classes should not be extensible.
 * Responsibility: simulates a player playing the roulette game for a certain time
 * interacts with a Player & Game and containts Statistics
 */

public final class Simulation {
    
    private Player player;
    private Game game;
    private Statistics stats;

    /**
     * Simulation creates a new simulation for the given player (strategy).
     * @param p the player
     * @param g the game to play
     */
    public Simulation(Player p, Game g) {
        this.player = p;
        this.game = g;
    }
    
    /**
     * session simulates the game until the player withdraws.
     */
    public void session() {
        while (player.plays()) {
            game.cycle(player);
        }
    }
    
    /**
     * getStats returns the statistics object.
     * @return the stats corresponding to the execution so far
     */
    public Statistics getStats() {
        return stats;
    }   
    
    /**
     * Main method.
     */
    public static void main(String[] args) {
        
    }
    
}