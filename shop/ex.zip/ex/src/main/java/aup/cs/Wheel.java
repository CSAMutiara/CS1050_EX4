package aup.cs;

import java.util.Arrays;
import java.util.Random;

/**
 * The class is defined as final since utility classes should not be extensible.
 * Responsibility: Selects winning bings
 * Interacts: with Bins
 */

public final class Wheel {
    
    private Bin[] bins;
    
    /**
     * Wheel constructor.
     */
    public Wheel() {
        bins = new Bin[38];
        for (int i = 0; i <= 37; i++) {
            bins[i] = new Bin();
        }
        BinBuilder.buildBins(this);
    }
    
    /**
     * addOutcome adds:.
     * @param o an Outcome to
     * @param bin an int
     */
    public void addOutcome(int bin, Outcome o) {
        bins[bin].addOutcome(o);
    }
    
    /**
     * next returns the winning Bin (?).
     * @return null (the winning Bin?)
     */
    public Bin next() {
        Random rand = new Random();
        int r = rand.nextInt(37);
        return bins[r];
    }
    
    /**
     * getBins for each bin outcome....
     * @return the outcome array of possible outcomes
     */
    public Bin[] getBins() {
        return bins;
    }
    
}